document.addEventListener('DOMContentLoaded', function() {
    const keywordsForm = document.getElementById('keywordsForm');
    const titlesSection = document.getElementById('titlesSection');
    const proposalSection = document.getElementById('proposalSection');
    const titlesList = document.getElementById('titlesList');
    const proposalContent = document.getElementById('proposalContent');
    const downloadBtn = document.getElementById('downloadBtn');

    // Add keyword field dynamically
    window.addKeywordField = function() {
        const keywordInputs = document.getElementById('keywordInputs');
        const inputCount = keywordInputs.children.length;
        
        if (inputCount >= 5) {
            alert('최대 5개의 키워드까지 입력 가능합니다');
return;
        }

        const newInput = document.createElement('div');
        newInput.className = 'flex items-center space-x-2';
        newInput.innerHTML = `
            <input type="text" name="keyword${inputCount + 1}" placeholder="Enter keyword" 
                class="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500">
            <button type="button" onclick="this.parentNode.remove()" class="p-2 rounded-full bg-gray-100 text-gray-600 hover:bg-gray-200">
                <i data-feather="x"></i>
            </button>
        `;
        keywordInputs.appendChild(newInput);
        feather.replace();
    };

    // Handle form submission
    keywordsForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Show loading state
        titlesList.innerHTML = `
            <div class="flex items-center justify-center py-8">
                <div class="animate-pulse flex space-x-4">
                    <div class="h-12 w-12 rounded-full bg-primary-200"></div>
                </div>
            </div>
        `;
        titlesSection.classList.remove('hidden');
        
        // Simulate API call (replace with actual OpenAI API call)
        setTimeout(() => {
            const formData = new FormData(keywordsForm);
            const keywords = Array.from(formData.values()).filter(val => val.trim() !== '');
            
            // Generate sample titles (replace with AI-generated titles)
            const sampleTitles = [
                `Innovative ${keywords.join(' ')} Business Proposal`,
                `${keywords[0]} Market Expansion Strategy`,
                `Sustainable ${keywords.slice(0, 2).join(' ')} Solution`,
                `Digital Transformation for ${keywords[0]} Industry`,
                `${keywords[0]} ${keywords[1]} Partnership Framework`
            ];
            
            // Display titles
            titlesList.innerHTML = '';
            sampleTitles.forEach((title, index) => {
                const titleElement = document.createElement('div');
                titleElement.className = 'p-4 border border-gray-200 rounded-lg hover:bg-primary-50 cursor-pointer transition';
                titleElement.innerHTML = `
                    <h3 class="font-medium text-gray-800">${title}</h3>
                <p class="text-sm text-gray-500 mt-1">클릭하여 전체 제안서 생성</p>
`;
                titleElement.addEventListener('click', () => generateProposal(title, keywords));
                titlesList.appendChild(titleElement);
            });
        }, 1500);
    });

    // Generate proposal content
    function generateProposal(title, keywords) {
        // Show loading state
        proposalContent.innerHTML = `
            <div class="flex items-center justify-center py-12">
                <div class="animate-pulse flex flex-col items-center space-y-4">
                    <div class="h-12 w-12 rounded-full bg-primary-200"></div>
                    <div class="h-4 w-32 bg-primary-200 rounded"></div>
                </div>
            </div>
        `;
        proposalSection.classList.remove('hidden');
        
        // Scroll to proposal section
        proposalSection.scrollIntoView({ behavior: 'smooth' });
        
        // Simulate API call (replace with actual OpenAI API call)
        setTimeout(() => {
            // Generate sample proposal (replace with AI-generated content)
            const sampleProposal = `
                <h2>${title}</h2>
                <h3>Business Overview</h3>
                <p>This proposal outlines a comprehensive business plan leveraging ${keywords.join(', ')} to create innovative solutions in the target market. Our approach combines cutting-edge technology with sustainable practices to deliver exceptional value.</p>
                
                <h3>Market Need</h3>
                <p>The current market shows significant demand for ${keywords[0]} solutions, with an estimated growth rate of 15% annually. Our analysis indicates that ${keywords.slice(1, 3).join(' and ')} are key differentiators that will drive adoption.</p>
                
                <h3>Solution</h3>
                <p>We propose a three-phase implementation:</p>
                <ul>
                    <li>Phase 1: Market research and ${keywords[0]} prototype development</li>
                    <li>Phase 2: Pilot program with select partners</li>
                    <li>Phase 3: Full-scale rollout with ${keywords[2]} integration</li>
                </ul>
                
                <h3>Financial Projections</h3>
                <p>Based on conservative estimates, this venture is projected to generate $2.5M in revenue within the first three years, with a 35% gross margin.</p>
            `;
            
            proposalContent.innerHTML = sampleProposal;
        }, 2000);
    }

    // Handle download button click
    downloadBtn.addEventListener('click', function() {
        // In a real implementation, this would call your Python backend to generate the HWPX file
        alert('실제 구현에서는 Python 백엔드와 연결하여 HWPX 파일로 다운로드됩니다.');
});
});