class CustomNavbar extends HTMLElement {
  connectedCallback() {
    this.attachShadow({ mode: 'open' });
    this.shadowRoot.innerHTML = `
      <style>
        :host {
          display: block;
          width: 100%;
        }
        nav {
          background-color: white;
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        .container {
          max-width: 1200px;
          margin: 0 auto;
          padding: 1rem 2rem;
        }
        .logo {
          font-weight: 700;
          font-size: 1.25rem;
          color: #0ea5e9;
        }
        .nav-link:hover {
          color: #0284c7;
        }
      </style>
      <nav>
        <div class="container mx-auto flex justify-between items-center">
          <a href="/" class="logo flex items-center space-x-2">
            <i data-feather="zap"></i>
            <span>BizGenius AI</span>
          </a>
          <div class="flex items-center space-x-6"></div>
</div>
      </nav>
    `;
  }
}
customElements.define('custom-navbar', CustomNavbar);